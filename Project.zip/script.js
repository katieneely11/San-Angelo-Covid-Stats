// Software Engineering Project 
// Kaitlyn Neely and Darian Espinoza 

document.addEventListener('DOMContentLoaded', function () {
   'use strict';
   
}, false);